/*
 * File:   ShoppingCarts.hpp
 * Author: student
 *
 * Created on February 17, 2017, 11:38 AM
 */

#ifndef SHOPPINGCARTS_HPP
#define SHOPPINGCARTS_HPP

#include "AbsUserCart.hpp"
#include "PublicCart.hpp"

#endif /* SHOPPINGCARTS_HPP */
