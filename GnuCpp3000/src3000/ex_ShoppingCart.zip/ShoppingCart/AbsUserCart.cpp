#include "ShoppingCarts.hpp"

using namespace ShoppingCart;
using namespace MyUserCart01;

int AbsUserCart::addItem(int item) {
  int* pszArray = new int[count + 1];
  for (int ss = 0; ss < count; ss++)
    pszArray[ss] = items[ss];
  pszArray[count] = item;
  delete items;
  items = pszArray;
  return count++;
}

AbsUserCart& Create(ShopperType type, UserData user) {
  switch (type) {
    case ShopperType::stPublic:
      return *(new PublicCart(user));
  }
}
