#ifndef ACT320_ABSUSERCART_HPP
#define ACT320_ABSUSERCART_HPP

// Include options:
#include "../../ShoppingCart01/Headers/Products.hpp"  // Relative
#include "UserData.hpp"  // "-I" provided, or PATH Environment Variable

// Protected Constructor
// Cannot be directly constructed. Needs Factory in Child / Derived Class.
// TODO: Implement AbsUserCart - See "AbsUserCart1" for inspiration
// TODO: Create a Child Class (like "FrankenCart")
// TODO:    Re-use protected AbsUserCart constructor
// TODO:    Create Factory for your child implementation
// TODO: Create Test Case

namespace MyUserCart01 {

class AbsUserCart {
 protected:
  ShoppingCart::UserData& user;

  AbsUserCart(ShoppingCart::UserData& user) : user(user) {}

  virtual float getDiscount() = 0;

 public:
  virtual float getBalance() = 0;
  virtual bool isAvailable(int item) = 0;
  virtual int addItem(int item) = 0;
};
}

#endif /* ACT320_ABSUSERCART_HPP */
