#ifndef EMPLOYEECART_HPP
#define EMPLOYEECART_HPP
#include "ShoppingCarts.hpp"

namespace ShoppingCart {

class EmployeeCart : public AbsUserCart {
 protected:
  virtual float getDiscount(int count, int* items) { return 10.0f; }

 public:
  EmployeeCart(UserData& user) : AbsUserCart(user) {}
};
}

#endif /* EMPLOYEECART_HPP */
