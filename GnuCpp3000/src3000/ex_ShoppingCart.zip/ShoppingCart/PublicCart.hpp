#ifndef PUBLICCART_HPP
#define PUBLICCART_HPP

#include "ShoppingCarts.hpp"

namespace ShoppingCart {

class PublicCart : public AbsUserCart {
 protected:
  virtual float getDiscount(int count, int* items) { return 0.0f; }

 public:
  PublicCart(UserData& user) : AbsUserCart(user) {}
};
}

#endif /* PUBLICCART_HPP */
