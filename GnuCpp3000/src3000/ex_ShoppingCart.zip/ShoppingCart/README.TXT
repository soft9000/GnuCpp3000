Conceptual usage only - 

