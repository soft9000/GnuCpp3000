#ifndef COMMON_HPP_
#define COMMON_HPP_

#include <cstdlib>
#include <iostream>

using namespace std;

#include "Person.hpp"
#include "Place.hpp"
#include "Thing.hpp"

#endif /* COMMON_HPP_ */
