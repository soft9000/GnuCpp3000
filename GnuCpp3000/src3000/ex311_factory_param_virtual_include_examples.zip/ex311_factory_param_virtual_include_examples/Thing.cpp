#include "Common.hpp"

namespace BlogNouns {

Thing& Thing::Create(Types which) {
  switch (which) {
    default:
    case typeThing:
      return *(new Thing);
    case typePerson:
      return *(new Person);
    case typePlace:
      return *(new Place);
  }
}
}
