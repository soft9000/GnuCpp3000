#include "Common.hpp"

using namespace BlogNouns;

#if 0

int main(int argc, char** argv) {
    cout << "All Things" << endl;
    Thing& noun = Thing::Create(Types::typePerson);
    noun.speak();
    delete &noun;

    noun = Thing::Create(Types::typePlace);
    noun.speak();
    delete &noun;

    noun = Thing::Create(Types::typeThing);
    noun.speak();
    delete &noun;

    return 0;
}

#else

int main(int argc, char** argv) {
  cout << "BlogNouns" << endl;
  Person& person = (Person&)Thing::Create(Types::typePerson);
  person.speak();
  delete &person;

  Place& place = (Place&)Thing::Create(Types::typePlace);
  place.speak();
  delete &place;

  Thing& thing = Thing::Create(Types::typeThing);
  thing.speak();
  delete &thing;

  return 0;
}
#endif
