#ifndef PERSON_HPP_
#define PERSON_HPP_

#include "Common.hpp"

namespace BlogNouns {

class Person : public Place {
 public:
  Person() { cout << "Person()" << endl; }
  virtual ~Person() { cout << "~Person()" << endl; }

  virtual void speak(const char* psz = "Ima Person") {
    cout << "Person: " << psz << endl;
  }
};
}

#endif /* PERSON_HPP_ */
