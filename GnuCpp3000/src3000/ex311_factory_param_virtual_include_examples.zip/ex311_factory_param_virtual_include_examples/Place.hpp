#ifndef PLACE_HPP_
#define PLACE_HPP_
#include "Common.hpp"

namespace BlogNouns {

class Place : public Thing {
 public:
  Place() { cout << "Place()" << endl; }
  virtual ~Place() { cout << "~Place()" << endl; }
  virtual void speak(const char* psz = "Ima Place") {
    cout << "Place: " << psz << endl;
  }
};
}

#endif /* PLACE_HPP_ */
