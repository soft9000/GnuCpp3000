#ifndef THING_HPP_
#define THING_HPP_
#include "Common.hpp"

namespace BlogNouns {

enum Types { typeThing, typePlace, typePerson };

class Thing {
 public:
  Thing() { cout << "Thing()" << endl; }
  virtual ~Thing() { cout << "~Thing()" << endl; }
  virtual void speak(const char* psz = "Ima Thing") {
    cout << "Thing: " << psz << endl;
  }

  static Thing& Create(Types which);
};
}

#endif /* THING_HPP_ */
