#ifndef zera_hpp1
#define zera_hpp1

#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <string>
#include <fstream>
#include <sstream>

#include "TimeStruct.hpp"
#include "TimeInfo.hpp"
#include "TimeFormat.hpp"
#include "LogEntry.hpp"
#include "File.hpp"

#endif
