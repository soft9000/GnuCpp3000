#ifndef zera_hpp0
#define zera_hpp0

#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <string>
#include <fstream>
#include <sstream>

#include "TimeStruct.hpp"
#include "TimeInfo.hpp"
#include "TimeFormat.hpp"
#include "File.hpp"
#include "LogWriter.hpp"

#endif
