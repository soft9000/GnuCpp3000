#ifndef LogEntry_hpp0
#define LogEntry_hpp0

#include "era.hpp"

namespace era01 {

class LogEntry {
 private:
  TimeInfo zTime;
  string zMsg;

 public:
  LogEntry();
  LogEntry(const char* msg);
  LogEntry(const LogEntry& obj);
  LogEntry(const TimeInfo& entry, string msg);
  virtual ~LogEntry() {}

  bool parse(string);
  bool sameDate(const LogEntry& ref) const;

  virtual TimeInfo time() const;
  virtual string entry() const;
  virtual string message() const;
};
}

#endif
