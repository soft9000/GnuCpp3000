#ifndef EraFile_hpp0
#define EraFile_hpp0

#include "era.hpp"

namespace era01 {

class File {
 private:
  string sFQName, pdir;
  fstream* pIOStream = NULL;

 public:
  File();
  File(string fname);
  File(const File& file);

  void assign(const File& file);
  string home(string node);
  bool exists();
  const char* name();

  istream& openRead();
  ostream& openWrite();
  ostream& openAppend();
  iostream& openReadWrite();
  void close();
  bool remove();
};
}

#endif
