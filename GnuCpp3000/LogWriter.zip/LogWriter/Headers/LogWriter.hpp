#ifndef LogWriter_hpp0
#define LogWriter_hpp0

#include <era.hpp>

namespace era01 {

class LogWriter {
 protected:
  File file;

 public:
  LogWriter(const File& file);
  int count();
  bool exists();
  bool remove();
  bool append(string messsage);
  bool append(const LogEntry& messsage);
};
}

#endif
